import { Outlet } from "react-router-dom";

export const TodoLayout = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};
