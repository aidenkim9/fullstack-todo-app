import AppRouter from "./routes/Approuter";

function App() {
  return <AppRouter />;
}

export default App;
