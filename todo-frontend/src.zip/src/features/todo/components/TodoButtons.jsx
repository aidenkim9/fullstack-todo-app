import { Btn } from "../../../shared/ui/Btn";

export const TodoButtons = ({
  editId,
  todo,
  handleUpdate,
  handleEdit,
  handleDelete,
}) => {
  return (
    <div>
      {editId === todo.id ? (
        <Btn action="저장" color="blue" actionFn={handleUpdate} todo={todo} />
      ) : (
        <Btn action="수정" color="teal" actionFn={handleEdit} todo={todo} />
      )}
      <Btn action="삭제" color="rose" actionFn={handleDelete} todo={todo} />
    </div>
  );
};
