export const Btn = ({ action, color, actionFn, todo }) => {
  return (
    <>
      <button
        className={`border p-1 rounded bg-${color}-500 text-white hover:text-red-200 cursor-pointer`}
        onClick={() => actionFn(todo)}
      >
        {action}
      </button>
    </>
  );
};
