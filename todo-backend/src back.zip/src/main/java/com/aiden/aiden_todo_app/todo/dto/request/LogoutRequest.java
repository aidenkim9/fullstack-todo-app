package com.aiden.aiden_todo_app.todo.dto.request;

public class LogoutRequest {
    private String refreshToken;

    public String getRefreshToken() {
        return refreshToken;
    }
}
