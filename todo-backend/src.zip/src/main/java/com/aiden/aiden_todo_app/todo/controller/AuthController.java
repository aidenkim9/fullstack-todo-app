package com.aiden.aiden_todo_app.todo.controller;

import com.aiden.aiden_todo_app.todo.dto.request.LoginRequest;
import com.aiden.aiden_todo_app.todo.dto.request.LogoutRequest;
import com.aiden.aiden_todo_app.todo.dto.response.LoginResponse;
import com.aiden.aiden_todo_app.todo.dto.request.RefreshRequest;
import com.aiden.aiden_todo_app.todo.entity.RefreshToken;
import com.aiden.aiden_todo_app.todo.entity.User;
import com.aiden.aiden_todo_app.todo.repository.RefreshTokenRepository;
import com.aiden.aiden_todo_app.todo.repository.UserJpaRepository;
import com.aiden.aiden_todo_app.todo.security.jwt.JwtUtil;
import com.aiden.aiden_todo_app.todo.service.AuthService;
import io.jsonwebtoken.Claims;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;
    private final RefreshTokenRepository refreshTokenRepository;
    private final UserJpaRepository userJpaRepository;


    public AuthController
            (AuthService authService,
             RefreshTokenRepository refreshTokenRepository,
             UserJpaRepository userJpaRepository ) {
        this.authService = authService;
        this.refreshTokenRepository = refreshTokenRepository;
        this.userJpaRepository = userJpaRepository;
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) throws IllegalAccessException {

        return authService.login(request);

    }

    @PostMapping("/logout")
    public String logout(@RequestBody LogoutRequest request) {

        authService.logout(request.getRefreshToken());
        return "logout";

    }

    @PostMapping("/refresh")
    public LoginResponse refresh(@RequestBody RefreshRequest request){

        RefreshToken refreshToken = refreshTokenRepository.findByToken(request.getRefreshToken()).orElseThrow(
                () -> new RuntimeException("Invalid refresh token")
        );

        Claims claims = JwtUtil.parseToken(refreshToken.getToken());
        String username = claims.getSubject();

        User user = userJpaRepository.findByUsername(username).orElseThrow();

        String newAccess = JwtUtil.createAccessToken(user);

        return new LoginResponse(newAccess, refreshToken.getToken());

    }
}
