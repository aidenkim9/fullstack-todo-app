package com.aiden.aiden_todo_app.todo.dto.request;

public class TodoCreateRequest {

    private String title;

    public String getTitle() {
        return title;
    }
}
