package com.aiden.aiden_todo_app.todo.dto.request;

public class RefreshRequest {

    private String refreshToken;

    public String getRefreshToken() {
        return refreshToken;
    }
}
