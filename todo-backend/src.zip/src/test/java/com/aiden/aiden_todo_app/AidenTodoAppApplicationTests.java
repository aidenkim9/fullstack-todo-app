package com.aiden.aiden_todo_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AidenTodoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
